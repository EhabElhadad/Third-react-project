import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
// import deEllyBetb3atEllActionLLProps from '../actionCreators/counterAction';
import { inc, dec } from '../actionCreators/counterAction';
import deEllyBetb3atEllStateLLProps from '../dispatch/dispatch';




class Navbar extends Component {
    render() {
        // console.log("Navbar counter",this.props);
        return (
            <Fragment>
                <div className="text-center bg-success py-3">
                    <h1>Navbar counter:{this.props.x}</h1>
                    <button onClick={this.props.inc} className="btn btn-primary">increament</button>
                    <button onClick={this.props.dec} className="btn btn-dark m-3">decreament</button>
                </div>
            </Fragment>
        )
    }
}



export default connect(deEllyBetb3atEllStateLLProps, { inc, dec })(Navbar)