import axios from "axios";





export function getMovies() {
    return async function (dispatch) {
      let {data} = await axios.get("https://api.themoviedb.org/3/movie/now_playing?api_key=eba8b9a7199efdcb0ca1f96879b83c44&fbclid=IwAR3G5Y3el8okT71j8i8RUwYKOfNtp-R_Ox1P7b9dnA6noImL2GEeL282mlo")
      dispatch({ type: "GETMOVIES",payload:data.results });
    };
  }
