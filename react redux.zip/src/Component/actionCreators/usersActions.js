import axios from "axios"


export function getUsers(){
    return async function(dispatch){
      let {data} = await axios.get(`http://route-egypt-api.herokuapp.com/getAllUsers?page=18`)
        return dispatch({type:"GETUSERS",payload:data.Users})
    }
}