import axios from "axios";
 






export function getRecipes() {
    return async function (dispatch) {
      let {data} = await axios.get("https://forkify-api.herokuapp.com/api/search?q=pizza")
      dispatch({ type: "getRecipes",payload:data.recipes });
    };
  }









// async function deEllyBetb3atEllActionLLProps(dispatch){
//    let {data} = await axios.get("https://forkify-api.herokuapp.com/api/search?q=pizza")
//    console.log(data.recipes);
//    return dispatch({type:"getRecipes" , payload:data.recipes})
//  }

//  export default connect(deEllyBetb3atEllActionLLProps)