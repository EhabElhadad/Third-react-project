// function deEllyBetb3atEllActionLLProps(dispatch){
//     return{
//         inc:()=>dispatch({type:"hyzawed"}),
//         dec:()=>dispatch({type:"hyna2as"}),

//     }
//     }

//     export default deEllyBetb3atEllActionLLProps

export function inc() {
  return function (dispatch) {
    dispatch({ type: "hyzawed" });
  };
}

export function dec() {
  return function (dispatch) {
    dispatch({ type: "hyna2as" });
  };
}
