import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux';
import { getRecipes } from '../actionCreators/RecipesAction';


 class Recipes extends Component {

    componentDidMount(){
        this.props.getRecipes()
    }
    render() {
        // console.log(this.props);
        return (
            <Fragment>
                <h1 className="text-center">Pizza recipes</h1>

            
                <div className="container">
                    <div className="row">
                        {this.props.recipes.map((value, index) => {
                           return <div key={index} className="col-md-4">
                                <img src={value.image_url} className="img-fluid m-2" style={{width:"300px",height:"200px"}}/>
                            </div>;
                        })}
                    </div>
                </div>
            </Fragment>
        )
    }
}


function deEllyBetb3atEllStateLLProps(state){
    return{recipes:state.recipes}
    }
    

    


export default connect(deEllyBetb3atEllStateLLProps,{getRecipes})(Recipes)