import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import { getMovies } from '../actionCreators/moviesAction';

class Movies extends Component {

    componentDidMount() {
        this.props.getMovies()
    }
    render() {
        console.log(this.props);
        return (
            <Fragment>
                <div className="container my-5 text-center text-white">
                    <h1 className="my-3">Movies</h1>
                    <div className="row">
                        {this.props.movies.map((value, index) => {
                            return <div key={index} className="col-md-4">
                                <img src={value.poster_path} alt="" />
                                <h4 onKeyUp>{value.original_title}</h4>
                            </div>
                            
                        })}
                    </div>
                </div>
            </Fragment>
        )
    }
}


function deEllyBetb3atEllStateLLProps(state) {
    return { movies: state.movies }
}




export default connect(deEllyBetb3atEllStateLLProps, { getMovies })(Movies)