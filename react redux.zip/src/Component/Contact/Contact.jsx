import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import { inc, dec } from '../actionCreators/counterAction';
// import deEllyBetb3atEllActionLLProps from '../actionCreators/counterAction';
import deEllyBetb3atEllStateLLProps from '../dispatch/dispatch';



class Contact extends Component {
    render() {
        // console.log("Contact counter", this.props);
        return (
            <Fragment>
                <div className="text-center bg-info py-5 my-3">
                    <h1>Contact counter:{this.props.x}</h1>
                    <button onClick={this.props.inc} className="btn btn-danger m-3">increament</button>
                    <button onClick={this.props.dec} className="btn btn-success">decreament</button>
                </div>
            </Fragment>
        )
    }
}





export default connect(deEllyBetb3atEllStateLLProps, { inc, dec })(Contact)