
function deEllyBetb3atEllStateLLProps(state){
    return{x:state.counter}
    }
    

    export default deEllyBetb3atEllStateLLProps