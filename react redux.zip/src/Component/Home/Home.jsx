import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
// import deEllyBetb3atEllActionLLProps from '../actionCreators/counterAction';
import { inc, dec } from '../actionCreators/counterAction';
import deEllyBetb3atEllStateLLProps from '../dispatch/dispatch';



class Home extends Component {
    render() {
        // console.log("Home counter",this.props);
        return (
            <Fragment>
                <div className="text-center bg-danger py-5 my-3">
                    <h1>Home counter:{this.props.x}</h1>
                    <button onClick={this.props.inc} className="btn btn-dark m-2">increament</button>
                    <button onClick={this.props.dec} className="btn btn-info">decreament</button>
                </div>
            </Fragment>
        )
    }
}






export default connect(deEllyBetb3atEllStateLLProps, { inc, dec })(Home)