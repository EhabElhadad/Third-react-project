


function reducer(prevState,action){
    // console.log(action);
if(action.type=="hyzawed"){
    return{...prevState,counter:prevState.counter+1}
}
else if(action.type=="hyna2as"){
return{...prevState,counter:prevState.counter-1}
}

else if(action.type=="getRecipes"){
    return {...prevState,recipes:action.payload}
}

else if(action.type=="GETMOVIES"){
    return {...prevState, movies:action.payload}
}
else if(action.type=="GETUSERS"){
    return {...prevState,users:action.payload}
}
    return prevState;

}

export default reducer