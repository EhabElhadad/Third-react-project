import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import { getUsers } from '../actionCreators/usersActions'

 class Users extends Component {

    componentDidMount(){
        this.props.getUsers()
    }
    render() {
        console.log(this.props);
        return (
            <Fragment>
                <div className="container my-5 text-center">
                    <h1 className="my-3"></h1>
              <table className="table table-striped table-hover table-danger">
               <thead>
                   <tr>
                       <th>First Name</th>
                       <th>Last Name</th>
                       <th>Email</th>
                       <th>Age</th>
                   </tr>
               </thead>
              {this.props.users.map((value,index)=>{
                  return  <tbody>
                    <tr>
                        <td>{value.first_name}</td>
                        <td>{value.last_name}</td>
                        <td>{value.email}</td>
                        <td>{value.age}</td>
                    </tr>
                  </tbody>
              })}
              </table>
                </div>
            </Fragment>
        )
    }
}


function deEllyBetb3atEllStateLLProps(state){
    return{users:state.users}
    }
    


export default connect(deEllyBetb3atEllStateLLProps,{getUsers})(Users)