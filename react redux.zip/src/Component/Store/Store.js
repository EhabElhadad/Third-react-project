import { applyMiddleware, createStore } from "redux";
import thunk from "redux-thunk";
import reducer from "../reducer/reducer";

let middleWears=[thunk];





let initialState={
    counter:10,
    recipes:[],
    movies:[],
    users:[],
}




let store=createStore(reducer,initialState,applyMiddleware(...middleWears))


export default store




