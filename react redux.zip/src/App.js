import React, { Component } from 'react'
import Contact from './Component/Contact/Contact.jsx'
import Home from './Component/Home/Home.jsx'
import Movies from './Component/Movies/Movies.jsx'
import Navbar from './Component/Navbar/Navbar.jsx'
import Recipes from './Component/Recipes/Recipes.jsx'
import Users from './Component/Users/Users.jsx'

export default class App extends Component {
  render() {
    return (
      <div>
        <Navbar/>
        <Home/>
        <Contact/>
        <Recipes/>
        <Movies/>
        <Users/>
      </div>
    )
  }
}
